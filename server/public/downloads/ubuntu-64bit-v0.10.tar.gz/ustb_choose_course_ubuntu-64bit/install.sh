mv libQt5XcbQpa.so.5 libQt5DBus.so.5 libQt5Gui.so.5 libQt5Network.so.5 libQt5Widgets.so.5 libQt5Core.so.5 libicui18n.so.54 libicudata.so.54 libicuuc.so.54 /usr/lib/x86_64-linux-gnu/

输入以下命令完成安装
chmod +x ./install.sh & sudo bash ./install.sh & chmod +x USTB-选课
输入完成后,运行即可
